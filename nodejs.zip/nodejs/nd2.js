const fileSystem = require('fs');

// reading the existing file using the node js
let text = fileSystem.readFileSync("new.txt","utf-8");
// console.log(text);

// creating the new file in node js
let new2 = fileSystem.writeFileSync("new2.txt",'this is the new text of the new file');
// new2 = new2.replace('new','this new word is being replaced');
// console.log(new2);
// console.log("Creating the new file.................");
// console.log(new2);

let new3 = fileSystem.readFileSync('new2.txt','utf-8');
new3 = new3.replace('new','new word has been replaced');
fileSystem.writeFileSync('newfile.txt',new3);



// const fs = require("fs");
